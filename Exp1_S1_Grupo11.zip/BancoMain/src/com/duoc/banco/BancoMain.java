package com.duoc.banco;

import com.duoc.clientes.Clientes;
import com.duoc.cuentasbancarias.CuentasBancarias;
import java.util.Scanner;

public class BancoMain {

    static int seleccionUsuario = 0;
    static int opcionUsuario = 0;
    static String ingresoRut = "";
    
    static Scanner teclado = new Scanner(System.in);
    
    static Clientes clientesBanco = new Clientes();
    static CuentasBancarias cuentasClientes = new CuentasBancarias();
    
    public static void main(String[] args) { 
        
        do {
        
        System.out.println("------------------------------ BIENVENIDOS A BANCO INTERNACIONAL F.S.A. ------------------------------ ");
        System.out.println("Por favor, DIGITE una opción válida: ");
        System.out.println("[1] Para REGISTRARSE como Nuevo Cliente de Bancos F.S.A.");
        System.out.println("[2] Para ACCEDER a tu Sucursal Virtual. RUT Requerido");
        System.out.println("[3] Para SALIR");
        opcionUsuario = teclado.nextInt();
        
        if (opcionUsuario == 1) {
        clientesBanco.registrarCliente();
        } else if (opcionUsuario == 2) {
        teclado.nextLine();
            System.out.println("Por favor, ingrese su RUT de Cliente. Recuerde que para acceder a Sucursal Virtual, usted debe ser Cliente.");
            ingresoRut = teclado.nextLine();
            
            if (ingresoRut.equals(clientesBanco.getRut())) {
           do { 
            
        System.out.println("-------------------------- BIENVENIDO A SUCURSAL VIRTUAL BANCO INTERNACIONAL F.S.A. --------------------------"); 
        System.out.println("Por favor, DIGITE una opción válida: ");
        System.out.println("[1] Para VER tus datos de cliente");
        System.out.println("[2] Para DEPOSITAR dinero en tu cuenta");
        System.out.println("[3] Para RETIRAR dinero de tu cuenta");
        System.out.println("[4] Para CONSULTAR tu saldo");
        System.out.println("[5] Para SALIR");
        seleccionUsuario = teclado.nextInt();
        
        switch (seleccionUsuario) {
        
            case 1: clientesBanco.verDatosCliente();
            break;
            case 2: cuentasClientes.depositarDinero();
            break;
            case 3: cuentasClientes.retirarDinero();
            break;
            case 4: cuentasClientes.consultarSaldo();
            break;
            default: System.out.println("Por favor digita una opción válida.");
            return;             
        }
        
    } while (seleccionUsuario != 5);  
            
        } else {
            System.out.println("RUT no válido. Por favor, intente nuevamente");
        } 
        } else if (opcionUsuario != 3) {
        System.out.println("Por favor ingrese una opción válida");
                }
        } while (opcionUsuario != 3);
                System.out.println("Gracias por usar Banco Internacional F.S.A.");
        
                
    teclado.close();
    }
}