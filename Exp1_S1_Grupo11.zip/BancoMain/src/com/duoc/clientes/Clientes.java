package com.duoc.clientes;

import com.duoc.cuentasbancarias.CuentasBancarias;
import java.util.Scanner;

public class Clientes {
    
    private String rut;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String domicilio;
    private String comuna;
    private int telefono;
    private int cuentaBancaria;
    public int numeroCuentaUsuario = 0;
    public int saldoUsuarioRegistro = 0;
       
    static CuentasBancarias cuentasClientes = new CuentasBancarias();
    static Scanner teclado = new Scanner(System.in);
    
    
    public Clientes() {
    }

    public Clientes(String rut, String nombre, String apellidoPaterno, String apellidoMaterno, String domicilio, String comuna, int telefono, int cuentaBancaria) {
        this.rut = rut;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.domicilio = domicilio;
        this.comuna = comuna;
        this.telefono = telefono;
        this.cuentaBancaria = cuentaBancaria;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public int getCuentaBancaria() {
        return cuentaBancaria;
    }

    public void setCuentaBancaria(int cuentaBancaria) {
        this.cuentaBancaria = cuentaBancaria;
    }
    
    public void registrarCliente() {
        System.out.println(" -------------------------- REGISTRO DE CLIENTES --------------------------");
        System.out.println("Esta es la plataforma de registro de clientes --- Banco Internacional FSA ---");
        System.out.println("Por favor, ingrese su Rut. Con puntos, guión y dígito verificador. Ejemplo: 18.739.412-0");
        String rutUsuario = teclado.nextLine();
        if (rutUsuario.length() >= 11 && rutUsuario.length() <= 12) {
            numeroCuentaUsuario = 100000000 + (int) (Math.random() * 900000000);
            saldoUsuarioRegistro = 0;
            setRut(rutUsuario);
            System.out.println("Rut ingresado correctamente");
        }
        else {
            System.out.println("Inválido. Por favor digite su rut. Con puntos, guión y dígito verificacor. Ejemplo: 18.739.412-0");
        }
        System.out.println("Ingrese su nombre completo. Ejemplo: Sebastian Alejandro");
        String nombreCompleto = teclado.nextLine();
        if (!nombreCompleto.isEmpty()) {
        setNombre(nombreCompleto);
            System.out.println("Nombre ingresado correctamente");
        } else {
            System.out.println("Inválido. Por favor ingrese su nombre completo. Ejemplo: Sebastián Alejandro");
        }
        System.out.println("Ingrese su Apellido Paterno. Ejemplo: Olave");
        String apellidoPaternoUsuario = teclado.nextLine();
        if (!apellidoPaternoUsuario.isEmpty()) {
            setApellidoPaterno(apellidoPaternoUsuario);
            System.out.println("Apellido Paterno ingresado correctamente");
        } else {
            System.out.println("Inválido. Por favor ingrese su Apellido Paterno. Ejemplo: Olave");
        }
        System.out.println("Ingrese su Apellido Materno. Ejemplo: Yanez");
        String apellidoMaternoUsuario = teclado.nextLine();
        if (!apellidoMaternoUsuario.isEmpty()) {
        setApellidoMaterno(apellidoMaternoUsuario);
            System.out.println("Apellido Materno ingresado correctamente");
        } else {
            System.out.println("Inválido. Por favor ingrese su Apellido Materno. Ejemplo: Yanez");
        }
        System.out.println("Ingrese su Domicilio. Ejemplo: La Nina #3560");
        String domicilioUsuario = teclado.nextLine();
        if (!domicilioUsuario.isEmpty()) {
        setDomicilio(domicilioUsuario);
            System.out.println("Domicilio ingresado correctamente");
        } else {
            System.out.println("Inválido. Por favor ingrese su domicilio. Ejemplo: La Nina #3560");
        }
        System.out.println("Ingrese su Comuna. Ejemplo: Cerrillos");
        String comunaUsuario = teclado.nextLine();
        if (!comunaUsuario.isEmpty()) {
        setComuna(comunaUsuario);
            System.out.println("Comuna ingresada correctamente");
        }
        System.out.println("Ingrese su Número de Teléfono: Ejemplo: 963867456");
        int telefonoUsuario = teclado.nextInt();
        if (telefonoUsuario >0) {
        setTelefono(telefonoUsuario);
            System.out.println("Telefono ingresado correctamente");
        } else {
            System.out.println("Inválido. Por favor ingrese su teléfono. Ejemplo: 963867456");
        }
        System.out.println("Proceso exitoso. Se ha creado tu cuenta Bancaria");
        System.out.println("A continuación, tu número de cuenta. ¡Anótalo, gúardalo! ¡No lo olvides!");
        System.out.println("Tu Número de cuenta es: " + numeroCuentaUsuario);
        setCuentaBancaria(numeroCuentaUsuario);
        cuentasClientes.setNumeroCuenta(numeroCuentaUsuario);
        cuentasClientes.setSaldo(saldoUsuarioRegistro);
        System.out.println("Muchas gracias por confiar en Bancos FSA. Estamos honrados de que nos hayas elegido como tu Banco");
        System.out.println("---------------------------- BANCO INTERNACIONAL F.S.A. ----------------------------");
    }
    
    public void verDatosCliente() {
        System.out.println("------------------------ MIS DATOS ------------------------");
            System.out.println("¡Bienvenido "+getNombre()+"!");
            System.out.println("El resumen de tus datos personales registrados en Bancos FSA: ");
            System.out.println("Rut: "+getRut());
            System.out.println("Nombre completo: "+getNombre());
            System.out.println("Apellido Paterno: "+getApellidoPaterno());
            System.out.println("Apellido Materno: "+getApellidoMaterno());
            System.out.println("Domicilio: "+getDomicilio());
            System.out.println("Comuna: "+getComuna());
            System.out.println("Teléfono: "+getTelefono());
            System.out.println("Número de cuenta corriente: "+cuentasClientes.getNumeroCuenta());
            System.out.println("Saldo: $ "+cuentasClientes.getSaldo()+" pesos.");
    }
    
}
