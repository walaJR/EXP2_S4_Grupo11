package com.duoc.cuentasbancarias;

import java.util.Scanner;

public class CuentasBancarias {
    
    private static int numeroCuenta;
    private static int saldo;
    public int saldoUsuario = 0;

    static Scanner teclado = new Scanner(System.in);
    public CuentasBancarias() {
    }

    public CuentasBancarias(int numeroCuenta, int saldo) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }
    
    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
    
    public void consultarSaldo() {
        System.out.println("------------------------- CONSULTA SALDO -------------------------");
        System.out.println("Tu saldo es: $ "+getSaldo()+" pesos.");
    }
    
    public void retirarDinero() {
        teclado.nextLine();
            System.out.println("---------------------------------- RETIRAR DINERO ----------------------------------");
            System.out.println("Por favor digita el monto que deseas retirar: ");
            int giroUsuario = teclado.nextInt();
            if (giroUsuario <= 0) {
                System.out.println("El monto a retirar debe ser mayor a 0 pesos");
            } else if (giroUsuario > getSaldo()) {
                System.out.println("El monto a retirar excede tu saldo actual");
            } else {
            int nuevoSaldo = getSaldo();
            nuevoSaldo = nuevoSaldo - giroUsuario;
            setSaldo(nuevoSaldo);
                System.out.println("¡Retiro exitoso! Tu nuevo saldo es: $ "+getSaldo()+" pesos.");
            }
    }
    
    public void depositarDinero() {
            System.out.println("----------------------------------- DEPOSITOS -----------------------------------");
            System.out.println("Por favor, indica el monto a depositar. Ejemplo: 50000");
            int deposito = teclado.nextInt(); 
            if (deposito > 0) {
            saldoUsuario = getSaldo();
            saldoUsuario = saldoUsuario + deposito;
            setSaldo(saldoUsuario);
            System.out.println("¡Depósito realizado!");
                System.out.println("Haz hecho un depósito por un total de: $ "+deposito+" pesos.");
            System.out.println("Tu nuevo saldo es: $ "+getSaldo()+" pesos.");
            } else {
                System.out.println("No se permite el ingreso de montos menores o iguales a 0 pesos. Por favor introduce un monto válido");
            }
    }
    
}
