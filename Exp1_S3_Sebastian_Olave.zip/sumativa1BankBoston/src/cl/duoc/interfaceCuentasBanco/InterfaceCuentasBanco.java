package cl.duoc.interfaceCuentasBanco;

public interface InterfaceCuentasBanco {
    
    public abstract void consultarSaldo();
    
}
