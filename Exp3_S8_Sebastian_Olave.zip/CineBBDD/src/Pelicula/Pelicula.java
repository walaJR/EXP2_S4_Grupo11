package Pelicula;

import com.toedter.calendar.JDateChooser;
import javax.swing.JTextField;
import Conexion.Conexion;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class Pelicula {
    
    public void agregarPelicula(JTextField titulo, JTextField director, JTextField duracion, JTextField genero, JDateChooser fechaPelicula, JTable listaPeliculas){
    
        Conexion conexion = new Conexion();
        
        String consulta = "INSERT INTO MOVIE (titulo_pelicula, director_pelicula, año_pelicula, duracion_pelicula, genero_pelicula) VALUES (?, ?, ?, ?, ?)";
        
        try{
        CallableStatement cs = conexion.establecerConexion().prepareCall(consulta);
        cs.setString(1, titulo.getText());
        cs.setString(2, director.getText());
        
        Date fechaSeleccionada = fechaPelicula.getDate();
        java.sql.Date fechaSQL = new java.sql.Date(fechaSeleccionada.getTime());
        
        cs.setDate(3, fechaSQL);
        cs.setInt(4, Integer.parseInt(duracion.getText()));
        cs.setString(5, genero.getText());
        cs.execute();
        JOptionPane.showMessageDialog(null, "La Película se ha guardado correctamente");
        
        }catch(SQLException e) {
        
            JOptionPane.showMessageDialog(null, "No se ha podido ingresar la nueva película. Intente nuevamente");
            
        }finally{
            
        conexion.desconectarBD();
        Pelicula listaBBDD = new Pelicula();
        listaBBDD.mostrarPeliculas(listaPeliculas);
        
        }
    }
    
    
    public void mostrarPeliculas(JTable tablaPeliculas){
        
        Conexion conexion = new Conexion();
        DefaultTableModel modelo = new DefaultTableModel();
        String consultaSQL = "SELECT * FROM MOVIE;";
        
        modelo.addColumn("ID_Película");
        modelo.addColumn("Título película");
        modelo.addColumn("Director película");
        modelo.addColumn("Año película");
        modelo.addColumn("Duración película");
        modelo.addColumn("Género película");
        
        tablaPeliculas.setModel(modelo);
        
        try{
        
            Statement st = conexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(consultaSQL);
            
            while(rs.next()) {
            
            String id = rs.getString("ID_Pelicula");
            String tituloPelicula = rs.getString("titulo_pelicula");
            String directorPelicula = rs.getString("director_pelicula");
            java.sql.Date fechaSQL = rs.getDate("año_pelicula");
            String duracionPelicula = rs.getString("duracion_pelicula");
            String generoPelicula = rs.getString("genero_pelicula");
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String nuevaFecha = sdf.format(fechaSQL);
            modelo.addRow(new Object [] {id, tituloPelicula, directorPelicula, nuevaFecha, duracionPelicula, generoPelicula});
            
            tablaPeliculas.setModel(modelo);
            }
            
        }catch(SQLException e){
        
            JOptionPane.showMessageDialog(null, "Error al mostrar la lista de base de datos");
            
        }
        
        finally {
        
        conexion.desconectarBD();
        }
    }
    
    
    public void modificarPelicula(JTextField idPelicula, JTextField titulo, JTextField director, JTextField duracion, JTextField genero, JDateChooser fechaPelicula, JTable listaPeliculas){
        
        Conexion conexion = new Conexion();
    
        String consultaSQL = "UPDATE movie SET movie.titulo_pelicula =?, movie.director_pelicula =?, movie.año_pelicula =?, movie.duracion_pelicula =?, movie.genero_pelicula =? WHERE movie.ID_Pelicula=?;";
        
        try{
            
            CallableStatement cs = conexion.establecerConexion().prepareCall(consultaSQL);
            cs.setString(1, titulo.getText());
            cs.setString(2, director.getText());
            
            Date fechaSeleccionada = fechaPelicula.getDate();
            java.sql.Date fechaSQL = new java.sql.Date(fechaSeleccionada.getTime());
            cs.setDate(3, fechaSQL);
            cs.setInt(4, Integer.parseInt(duracion.getText()));
            cs.setString(5, genero.getText());
            cs.setInt(6, Integer.parseInt(idPelicula.getText()));
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "La película se ha modificado correctamente");
            
        
        }catch(SQLException e){
            
            JOptionPane.showMessageDialog(null, "La película no se ha podido modificar");
        
        }finally{
        
        conexion.desconectarBD();
        Pelicula listaBBDD = new Pelicula();
        listaBBDD.mostrarPeliculas(listaPeliculas);
        
        }
    
    
    }
    
    
    public void eliminarPelicula(JTextField idPelicula, JTable listaPeliculas){
        
        Conexion conexion = new Conexion();
        
        String consultaSQL = "DELETE FROM movie WHERE movie.ID_Pelicula =?;";
        
        try{
            
            CallableStatement cs = conexion.establecerConexion().prepareCall(consultaSQL);
            cs.setInt(1, Integer.parseInt(idPelicula.getText()));
            cs.execute();
            JOptionPane.showMessageDialog(null, "La película ha sido eliminada con éxito");
            
        
        }catch(SQLException e){
        
            JOptionPane.showMessageDialog(null, "Error al eliminar la película. Intente otra vez");
        
        }finally{
        
            conexion.desconectarBD();
            Pelicula listaBBDD = new Pelicula();
            listaBBDD.mostrarPeliculas(listaPeliculas);
        
        }
    
    }
    
    
    
}
