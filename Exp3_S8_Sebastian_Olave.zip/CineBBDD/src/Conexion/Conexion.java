package Conexion;

import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection connect = null;
    
    String usuario = "root";
    String contraseña = "";
    String bd = "moviesDB";
    String ip = "localhost";
    String puerto = "3306";
    // jdbc:mysql://localhost:3306/moviesDB
    String cadenaConexion = "jdbc:mysql://"+ip+":"+puerto+"/"+bd;
    
    public Connection establecerConexion(){
    
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection(cadenaConexion, usuario, contraseña);
                    
        
        }catch (Exception e){
        
            JOptionPane.showMessageDialog(null, "No ha sido posible conectarse a la Base de Datos");
        }
        
        return connect;
    
    }
    
    public void desconectarBD(){
    
        try{
        
            if(connect != null && !connect.isClosed()) {
            connect.close();
            
            }
            
        }catch(Exception e){
        
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión a la Base de Datos.");
        }
    
    }
    
    
    
    
}
